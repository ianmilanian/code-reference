var margin  = {top: 30, right: 30, bottom: 30, left: 40},
    width   = 1100 - margin.left - margin.right,
    height  = 400 - margin.top - margin.bottom,
    delay   = 750,
    total   = 0;

var graph   = d3.select(".graph")
                .attr("width",  width  + margin.left + margin.right)
                .attr("height", height + margin.top  + margin.bottom)
                .append("g")
                    .attr("transform", "translate("+margin.left+","+margin.top+")");

var scale   = { x: d3.scale.linear().range([0, width]).domain([0, width]),
                y: d3.scale.linear().range([height, 0]).domain([height,0]),
                c: d3.scale.linear().range(["#8a89a6", "#7b6888", "#6b486b", "#a05d56", "#d0743c", "#ff8c00"]) };

/*
var scale   = { x: d3.scale.linear().range([0, width]),
                y: d3.scale.linear().range([height, 0]),
                c: d3.scale.linear().range(["#8a89a6", "#7b6888", "#6b486b", "#a05d56", "#d0743c", "#ff8c00"]) };
*/

var axis    = { x: d3.svg.axis().scale(scale.x).orient("bottom").ticks(5),
                y: d3.svg.axis().scale(scale.y).orient("left").ticks(5) };

var menu    = d3.select("#menu select");//.on("change", redraw);

function refresh() {
  // this should use the d3 exit function, but haven't figured that part out yet
  graph.selectAll("g")
        .transition()
        .duration(200)
        .attr("y", height)
        .style("fill-opacity", 1e-6)  // transition to 1e-6; smallest value not formatted in exponential notation
        .remove();
}