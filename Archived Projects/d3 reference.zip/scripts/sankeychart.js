function doSankeyChart() {
  refresh();
  
  var formatNumber = d3.format(",.0f"),    // decimal places
      units        = "Widgets",
      format       = function(d) { return formatNumber(d) + " " + units; },
      color        = d3.scale.category20();

  var sankey       = d3.sankey()
                        .nodeWidth(36)
                        .nodePadding(40)
                        .size([width, height]);

  var path         = sankey.link();
  
  d3.csv("data/sankeydata.csv", function(error, csv) {
    var data = csvToJson(csv);  // convert csv to json
    
    sankey.nodes(data.nodes)
          .links(data.links)
          .layout(32);

    var link = graph.append("g")
                    .selectAll(".sankeylink")
                    .data(data.links)
                    .enter()
                        .append("path")
                        .attr("class", "sankeylink")
                        .attr("d", path)
                        .style("stroke-width", function(d) { return Math.max(1, d.dy); })
                        .sort(function(a, b) { return b.dy - a.dy; });

    link.append("title")
        .text(function(d) { return d.source.name + " → " + d.target.name + "\n" + format(d.value); });
  
    var node = graph.append("g")
                    .selectAll(".sankeynode")
                    .data(data.nodes)
                    .enter()
                        .append("g")
                        .attr("class", "sankeynode")
                        .attr("transform", function(d) { return "translate(" + d.x + "," + d.y + ")"; })
                        .call(d3.behavior.drag()
                                          .origin(function(d) { return d; })
                                          .on("dragstart", function() { this.parentNode.appendChild(this); })
                                          .on("drag", dragmove));

    node.append("rect")
          .attr("height", function(d) { return d.dy; })
          .attr("width", sankey.nodeWidth())
          .style("fill", function(d) { return d.color = color(d.name.replace(/ .*/, "")); })
          .style("stroke", function(d) { return d3.rgb(d.color).darker(2); })
        .append("title")
          .text(function(d) { return d.name + "\n" + format(d.value); });

    node.append("text")
          .attr("x", -6)
          .attr("y", function(d) { return d.dy / 2; })
          .attr("dy", ".35em")
          .attr("text-anchor", "end")
          .attr("transform", null)
          .text(function(d) { return d.name; })
        .filter(function(d) { return d.x < width / 2; })
          .attr("x", 6 + sankey.nodeWidth())
          .attr("text-anchor", "start");

    function dragmove(d) {
      d3.select(this).attr("transform",
          "translate(" + (
              d.x = Math.max(0, Math.min(width - d.dx, d3.event.x))
          )
          + "," + (
              d.y = Math.max(0, Math.min(height - d.dy, d3.event.y))
          ) + ")");
      sankey.relayout();
      link.attr("d", path);
    }
  });
}

function csvToJson(csv) {
  json = {"nodes" : [], "links" : []};

  csv.forEach(function (d) {
    json.nodes.push({ "name": d.source });
    json.nodes.push({ "name": d.target });
    json.links.push({ "source": d.source, "target": d.target, "value": +d.value });
  });

  // return only the distinct / unique nodes
  json.nodes = d3.keys(d3.nest()
                          .key(function (d) { return d.name; })
                          .map(json.nodes));
  
  // loop through each link replacing the text with its index from node
  json.links.forEach(function (d, i) {
    json.links[i].source = json.nodes.indexOf(json.links[i].source);
    json.links[i].target = json.nodes.indexOf(json.links[i].target);
  });
  
  // loop through each nodes to make nodes an array of objects rather than an array of strings
  json.nodes.forEach(function (d, i) {
    json.nodes[i] = { "name": d };
  });
  
  return json;
}