function doBarChart() {
  refresh();
  
  d3.csv("data/bardata.csv", function(error, data) {
    menu.selectAll("option")
        .data(data)
        .enter()
          .append("option")
          .text(function(d) { return d.Site; });
  
    data.forEach(function (d) {
      d.Site  =  d.Site;
      d.Media = +d.Media; // +var to parse as int
      d.Data1 = +d.Data1;
      d.Data2 = +d.Data2;
      d.Data3 = +d.Data3;
    });
    
    // data = d3.nest()
    //           .key(function(d) { return d.Site; })
    //           .rollup(function(d) {
    //             return d3.min(d, function(g) {
    //               return Math.min(d.Data1, d.Data2, d.Data3); }); })  // Aggregate get the min data GROUPBY site
    //           .sortKeys(d3.ascending)
    //           .entries(csv);
    
    data.sort(function(lhs, rhs) { d3.ascending(lhs.Data1, rhs.Data1); });

    var min = d3.min(data, function(d) { return Math.min(d.Data1, d.Data2, d.Data3); });
    var max = d3.max(data, function(d) { return Math.max(d.Data1, d.Data2, d.Data3); });

    scale.x.domain([0, data.length]); //data.map(function(d) { return d.Data1; }));
    scale.y.domain([min, max]);
    scale.c.domain([0, data.length*0.2, data.length*0.4, data.length*0.6, data.length*0.8, data.length]);

    var zoom = d3.behavior.zoom()
                  .x(scale.x)
                  .scaleExtent([1, 1])
                  .on("zoom", function() {
                      var t  = zoom.translate(),
                          tx = t[0],
                          ty = t[1];
                
                      tx = Math.min(tx, 0);
                      tx = Math.max(tx, width - data.length);
                      zoom.translate([tx, ty]);

                      graph.select(".data").attr("d", rect);
                      //graph.select('.data').attr('d', line);
                  });

    var barWidth = 10;

    var bar = graph.selectAll("g.bar")
                    .data(data);

    var barEnter = bar.enter()
                      .append("g")
                      .attr("class", "bar");

    barEnter.append("rect")
            .attr("x", function(d, i) { return i*barWidth; }) //scale.x(d.Data1); })
            .attr("y", height)
            .attr("width", barWidth) //scale.x.rangeBand())
            .attr("height", 2)
            .attr("fill", function(d) { return scale.c(d.Data1); })
            .on("mouseover", function() {
                d3.select(this)
                  .attr("fill", "rgb(130, 250, 130)");
            })
            .on("mouseout", function(f, i) {
                d3.select(this)
                  .attr("fill", function(g) { return scale.c(g.Data1); });
            })
            .on("click", function(g, i) {
                d3.select(this)
                  .transition()
                  .duration(delay)
                  .attr("y", height)
                  .style("fill-opacity", 1e-6)  // transition to 1e-6; smallest value not formatted in exponential notation
                  .remove();
                                  
                d3.select("#text-"+i)
                  .transition()
                  .duration(delay)
                  .attr("y", height)
                  .style("fill-opacity", 1e-6)
                  .remove();
            })
            .call(zoom);
            
    barEnter.append("text")
            .attr("id", function(d, i) { return "text-"+i; })
            .attr("x", function(d, i) { return i*barWidth+6; }) //return scale.x(d.Data1)+6;})
            .attr("y", height-2)
            .text(function (d) { return d.Data1; });

    var barUpdate = bar.transition()
                        .duration(800)
                        .delay(function(d, i) { return i; });

    barUpdate.select("rect")
              .attr("y", function(d) { return scale.y(d.Data1); })
              .attr("height", function(d) { return height - scale.y(d.Data1); });

    barUpdate.select("text")
              .attr("y", function(d) { return scale.y(d.Data1)-2; });

    var barExit = bar.exit().transition()
                      .duration(delay)
                      .attr("y", height)
                      .style("fill-opacity", 1e-6)
                      .remove();
  
    //var brush = d3.brushX()
    //              .extent([0, 0], [width, height]);
                  //.on("brush", brushed);

    graph.append("g")
          .attr("class", "axis")
          .attr("transform", "translate(0, "+height+")")
          .call(axis.x);

    graph.append("g")
          .attr("class", "axis")
          .call(axis.y)
          .append("text")
              .attr("transform", "rotate(-90)")
              .attr("y", 10)
              .style("text-anchor", "end")
              .text("Values");

    graph.call(zoom);
  });
}